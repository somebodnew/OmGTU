import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.CountDownLatch;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class InheritanceIndexThreads {

    // class|interface Имя [extends ...] [implements ...] {
    private static final Pattern DECLARATION = Pattern.compile(
            "(?<![.\\w])(?:class|interface)\\s+(\\w+)"
                    + "(?:\\s+extends\\s+([^{]+?))?"
                    + "(?:\\s+implements\\s+([^{]+?))?"
                    + "\\s*\\{");

    public static void main(String[] args) throws IOException, InterruptedException {
        Path root = Paths.get(args.length > 0 ? args[0] : ".");
        long start = System.currentTimeMillis();

        List<Path> javaFiles;
        try (Stream<Path> files = Files.walk(root)) {
            javaFiles = files
                    .filter(p -> p.toString().endsWith(".java"))
                    .toList();
        }

        CountDownLatch latch = new CountDownLatch(javaFiles.size());

        List<Map<String, List<String>>> partialResults = new ArrayList<>();

        for (Path file : javaFiles) {
            Map<String, List<String>> local = new HashMap<>();
            partialResults.add(local);

            new Thread(() -> {
                try {
                    processFile(file, local);
                } catch (IOException e) {
                    System.err.println("Не удалось прочитать " + file + ": " + e.getMessage());
                } finally {
                    latch.countDown();
                }
            }).start();
        }

        latch.await();

        Map<String, List<String>> index = new TreeMap<>();
        for (Map<String, List<String>> local : partialResults) {
            local.forEach((parent, children) -> {
                List<String> list = index.getOrDefault(parent, new ArrayList<>());
                list.addAll(children);
                index.put(parent, list);
            });
        }

        long elapsed = System.currentTimeMillis() - start;

        index.forEach((parent, children) ->
                System.out.println(parent + " <- " + String.join(", ", children)));

        System.out.println();
        System.out.println("Файлов обработано (потоков создано): " + javaFiles.size());
        System.out.println("Родительских классов в индексе: " + index.size());
        System.out.println("Контрольная сумма индекса: " + index.hashCode());
        System.out.println("Время, мс: " + (elapsed));
    }

    private static void processFile(Path file, Map<String, List<String>> index) throws IOException {
        String code = new String(Files.readAllBytes(file), StandardCharsets.UTF_8);

        code = code.replaceAll("(?s)/\\*.*?\\*/", " ").replaceAll("//.*", " ");
        String withoutGenerics;
        do {
            withoutGenerics = code;
            code = code.replaceAll("<[^<>]*>", "");
        } while (!code.equals(withoutGenerics));

        Matcher m = DECLARATION.matcher(code);
        while (m.find()) {
            String child = m.group(1);
            Stream.of(m.group(2), m.group(3))
                    .filter(list -> list != null)
                    .flatMap(list -> Stream.of(list.split(",")))
                    .map(String::trim)
                    .map(name -> name.substring(name.lastIndexOf('.') + 1))
                    .filter(name -> !name.isEmpty())
                    .forEach(parent -> {
                        List<String> children = index.getOrDefault(parent, new ArrayList<>());
                        children.add(child);
                        index.put(parent, children);
                    });
        }
    }
}
