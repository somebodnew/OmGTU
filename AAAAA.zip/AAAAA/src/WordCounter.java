import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WordCounter {

    public static void main(String[] args) throws IOException {
        String path = args.length > 0 ? args[0] : "text.txt";
        String text = Files.readString(Paths.get(path));
        Pattern wordPattern = Pattern.compile("[\\p{L}\\p{N}]+");
        Matcher matcher = wordPattern.matcher(text);

        Map<String, Integer> counts = new TreeMap<>();
        while (matcher.find()) {
            String word = matcher.group().toLowerCase();
            counts.put(word, counts.getOrDefault(word, 0) + 1);
        }

        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue());
        }
    }
}
