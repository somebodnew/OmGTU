import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class InheritanceIndex {

    // class|interface Имя [extends ...] [implements ...] {
    private static final Pattern DECLARATION = Pattern.compile(
            "(?<![.\\w])(?:class|interface)\\s+(\\w+)"
                    + "(?:\\s+extends\\s+([^{]+?))?"
                    + "(?:\\s+implements\\s+([^{]+?))?"
                    + "\\s*\\{");

    public static void main(String[] args) throws IOException {
        Path root = Paths.get(args.length > 0 ? args[0] : ".");

        Map<String, List<String>> index = new TreeMap<>();

        try (Stream<Path> files = Files.walk(root)) {
            List<Path> javaFiles = files
                    .filter(p -> p.toString().endsWith(".java"))
                    .toList();
            for (Path file : javaFiles) {
                processFile(file, index);
            }
        }

        index.forEach((parent, children) ->
                System.out.println(parent + " <- " + String.join(", ", children)));
    }

    private static void processFile(Path file, Map<String, List<String>> index) throws IOException {
        String code = Files.readString(file);

        code = code.replaceAll("(?s)/\\*.*?\\*/", " ").replaceAll("//.*", " ");
        String withoutGenerics;
        do {
            withoutGenerics = code;
            code = code.replaceAll("<[^<>]*>", "");
        } while (!code.equals(withoutGenerics));

        Matcher m = DECLARATION.matcher(code);
        while (m.find()) {
            String child = m.group(1);
            Stream.of(m.group(2), m.group(3))
                    .filter(list -> list != null)
                    .flatMap(list -> Stream.of(list.split(",")))
                    .map(String::trim)
                    .map(name -> name.substring(name.lastIndexOf('.') + 1)) // a.b.Parent -> Parent
                    .filter(name -> !name.isEmpty())
                    .forEach(parent -> {
                        List<String> children = index.getOrDefault(parent, new ArrayList<>());
                        children.add(child);
                        index.put(parent, children);
                    });
        }
    }
}
