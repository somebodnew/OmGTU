// class Fake extends Animal {}
/* class Fake2 extends Animal {} */
class Animal {}
interface Walker {}
interface Swimmer {}
class Dog extends Animal implements Walker {}
class Duck extends Animal implements Walker, Swimmer {}
class Puppy extends Dog {}
interface Amphibian extends Walker, Swimmer {}
class Box<T extends Number> extends Container<T> implements Comparable<Box<T>> {}
class Container<T> {}
class MyList extends java.util.ArrayList<String> {}