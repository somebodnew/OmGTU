// class FakeLine extends Animal {}
/* class FakeBlock extends Animal {}
   interface FakeIface extends Walker {} */

class Animal {}

interface Walker {}
interface Swimmer {}
interface Flyer {}

class Dog extends Animal implements Walker {}
class Duck extends Animal implements Walker, Swimmer, Flyer {}
class Puppy extends Dog {}

interface Amphibian extends Walker, Swimmer {}
class Frog extends Animal implements Amphibian {}

class Box<T extends Number> extends Container<T> implements Comparable<Box<T>> {}
class Container<T> {}

class MyList extends java.util.ArrayList<String> {}
class MyMap<K, V> extends java.util.HashMap<K, V> implements java.io.Serializable {}

class Main {
    void m() {
        Class<?> c = Dog.class;
    }
}