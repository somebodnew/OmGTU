import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.TreeMap;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WordCounter {

    public static void main(String[] args) {
        Path filePath = Path.of("text.txt");

        String text;
        try {
            text = Files.readString(filePath);
        } catch (IOException e) {
            System.out.println("Не удалось прочитать файл: " + e.getMessage());
            return;
        }

        Map<String, Integer> wordCount = countWords(text);

        Map<String, Integer> sorted = new TreeMap<>(wordCount);
        for (Map.Entry<String, Integer> entry : sorted.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue());
        }
    }

    private static Map<String, Integer> countWords(String text) {
        Map<String, Integer> wordCount = new HashMap<>();
        String lowerText = text.toLowerCase();

        Pattern pattern = Pattern.compile("[\\p{L}]+(?:-[\\p{L}]+)*");
        Matcher matcher = pattern.matcher(lowerText);

        while (matcher.find()) {
            String word = matcher.group();
            wordCount.put(word, wordCount.getOrDefault(word, 0) + 1);
        }

        return wordCount;
    }
}